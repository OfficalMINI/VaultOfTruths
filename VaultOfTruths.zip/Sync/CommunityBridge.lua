------------------------------------------------------------------------
-- Vault of Truths - Sync/CommunityBridge.lua
-- Non-guildie support: shared channel discovery + whisper sync
-- Non-guildies can browse crafters, request crafts, track their orders.
-- They do NOT receive ledger, payouts, bank, settings, or reward data.
--
-- Discovery uses a single global channel "VaultOfTruths" that all addon
-- users join automatically. Guildies broadcast presence with their guild
-- name; non-guildies hear pings and auto-connect — zero manual setup.
------------------------------------------------------------------------
local ADDON_NAME, GF = ...

GF.CommunityBridge = {}
local CB = GF.CommunityBridge
GF:RegisterModule("CommunityBridge", CB)

local DISCOVERY_CHANNEL = "VaultOfTruths" -- Single global channel for all addon users

-- Online peers discovered via the shared channel
-- [guildName] = { [playerName] = { lastSeen, version } }
local discoveredPeers = {}

-- The channel index for the discovery channel
local discoveryChannelIndex = nil

-- Rate limiting for recipe requests: [sender] = lastRequestTime
local recipeRequestCooldowns = {}
local RECIPE_REQUEST_COOLDOWN = 60 -- seconds

local PRESENCE_INTERVAL = 60 -- seconds between presence pings
local PEER_TIMEOUT = 300 -- 5 minutes before pruning stale peers

function CB:Init()
    GF.Events:On("GF_PLAYER_LOGIN", function()
        C_Timer.After(8, function()
            CB:Setup()
        end)
    end)

    -- Listen for order status changes to notify external requesters
    GF.Events:On("GF_ORDER_ACCEPTED", function(order)
        CB:NotifyExternalRequester(order)
    end)
    GF.Events:On("GF_ORDER_COMPLETED", function(order)
        CB:NotifyExternalRequester(order)
    end)
    GF.Events:On("GF_ORDER_CANCELLED", function(order)
        CB:NotifyExternalRequester(order)
    end)
end

--- Join the global discovery channel and start appropriate behavior
function CB:Setup()
    -- Everyone joins the discovery channel
    self:JoinDiscoveryChannel()

    if IsInGuild() then
        -- Guildies: broadcast presence so non-guildies can find us
        local guildName = GetGuildInfo("player")
        if guildName then
            C_Timer.NewTicker(PRESENCE_INTERVAL, function()
                self:BroadcastPresence(guildName)
            end)
            -- Initial ping
            C_Timer.After(3, function()
                self:BroadcastPresence(guildName)
            end)
        end
    else
        -- Non-guildies: auto-sync recipes whenever we discover a guild
        C_Timer.NewTicker(120, function()
            self:AutoSyncRecipes()
        end)
        -- First sync attempt after presence pings have had time to arrive
        C_Timer.After(20, function()
            self:AutoSyncRecipes()
        end)
    end
end

--- Join the single global discovery channel
function CB:JoinDiscoveryChannel()
    local id = GetChannelName(DISCOVERY_CHANNEL)
    if id == 0 then
        JoinChannelByName(DISCOVERY_CHANNEL)
        C_Timer.After(2, function()
            local newId = GetChannelName(DISCOVERY_CHANNEL)
            if newId and newId > 0 then
                discoveryChannelIndex = newId
                if GF.debug then
                    GF.ChatNotify:Debug("Joined discovery channel (index " .. newId .. ")")
                end
            end
        end)
    else
        discoveryChannelIndex = id
    end
end

--- Broadcast presence on the discovery channel (guild members only)
---@param guildName string
function CB:BroadcastPresence(guildName)
    if not discoveryChannelIndex or discoveryChannelIndex == 0 then return end

    GF.Sender:SendChannel(GF.Protocol.MSG.CB_PRES, {
        guildName = guildName,
        playerName = GF.Utils:GetPlayerFullName(),
        version = GF.VERSION,
    }, discoveryChannelIndex)
end

--- Handle a presence ping from a guild member
---@param data table { guildName, playerName, version }
---@param sender string
function CB:OnPresenceReceived(data, sender)
    local guildName = data.guildName
    if not guildName then return end

    -- If we're in a guild, we only care about our own guild's peers
    if IsInGuild() then return end

    if not discoveredPeers[guildName] then
        discoveredPeers[guildName] = {}
    end

    local isNew = not discoveredPeers[guildName][sender]
    discoveredPeers[guildName][sender] = {
        lastSeen = time(),
        version = data.version,
        playerName = data.playerName,
    }

    -- Auto-connect: first time we see this guild, create external data and sync
    if isNew then
        local extData = GF.Settings:GetExternalGuildData(guildName)
        if extData.lastSync == 0 then
            -- First discovery of this guild — request recipes after a short delay
            C_Timer.After(5, function()
                self:RequestRecipes(guildName)
            end)
        end
    end
end

--- Get online peers for a guild, pruning stale entries
---@param guildName string
---@return table { [playerName] = { lastSeen, version } }
function CB:GetPeers(guildName)
    local peers = discoveredPeers[guildName]
    if not peers then return {} end

    local now = time()
    for name, peer in pairs(peers) do
        if now - peer.lastSeen > PEER_TIMEOUT then
            peers[name] = nil
        end
    end
    return peers
end

--- Get count of online peers for a guild
---@param guildName string
---@return number
function CB:GetPeerCount(guildName)
    local count = 0
    for _ in pairs(self:GetPeers(guildName)) do
        count = count + 1
    end
    return count
end

--- Get all discovered guild names
---@return table Array of guild name strings with online peers
function CB:GetDiscoveredGuilds()
    local guilds = {}
    for guildName, peers in pairs(discoveredPeers) do
        -- Only include guilds with live peers
        local hasLive = false
        local now = time()
        for _, peer in pairs(peers) do
            if now - peer.lastSeen <= PEER_TIMEOUT then
                hasLive = true
                break
            end
        end
        if hasLive then
            guilds[#guilds + 1] = guildName
        end
    end
    return guilds
end

--- Check if the current player is a non-guildie using external connections
---@return boolean
function CB:IsNonGuildie()
    return not IsInGuild()
end

--- Get the first connected external guild name (convenience for non-guildies)
---@return string|nil
function CB:GetConnectedGuild()
    -- Prefer guilds with online peers
    local discovered = self:GetDiscoveredGuilds()
    if #discovered > 0 then return discovered[1] end
    -- Fall back to stored external guilds
    local names = GF.Settings:GetExternalGuildNames()
    return names[1]
end

------------------------------------------------------------------------
-- Non-guildie: Recipe requests
------------------------------------------------------------------------

--- Request recipe catalog from all online peers of a guild
---@param guildName string
function CB:RequestRecipes(guildName)
    local peers = self:GetPeers(guildName)
    local sent = false

    for peerName in pairs(peers) do
        GF.Sender:SendTo(GF.Protocol.MSG.CB_RECIPE_REQ, {
            guildName = guildName,
        }, peerName)
        sent = true
    end

    if not sent and GF.debug then
        GF.ChatNotify:Debug("No peers online for " .. guildName)
    end
end

--- Auto-sync recipes from all discovered guilds
function CB:AutoSyncRecipes()
    if IsInGuild() then return end

    local guilds = self:GetDiscoveredGuilds()
    for _, guildName in ipairs(guilds) do
        self:RequestRecipes(guildName)
    end
end

--- Handle recipe request from a non-guildie (guild member responds)
---@param data table { guildName }
---@param sender string
function CB:OnRecipeRequest(data, sender)
    if not IsInGuild() then return end

    -- Rate limit
    local now = time()
    if recipeRequestCooldowns[sender] and now - recipeRequestCooldowns[sender] < RECIPE_REQUEST_COOLDOWN then
        return
    end
    recipeRequestCooldowns[sender] = now

    -- Verify we're in the requested guild
    local myGuild = GetGuildInfo("player")
    if not myGuild or myGuild ~= data.guildName then return end

    -- Build a stripped recipe catalog (no financial data)
    local guildData = GF.Settings:GetGuildData()
    if not guildData or not guildData.crafterRecipes then return end

    local catalog = {}
    for playerName, playerData in pairs(guildData.crafterRecipes) do
        local profs = {}
        for profName, profData in pairs(playerData.professions or {}) do
            local recipes = {}
            for _, recipe in ipairs(profData.recipes or {}) do
                recipes[#recipes + 1] = {
                    id = recipe.recipeID or recipe.id,
                    name = recipe.name,
                    reagents = recipe.reagents,
                    outputItemID = recipe.outputItemID,
                }
            end
            profs[profName] = { recipes = recipes, count = profData.count or #recipes }
        end
        catalog[playerName] = { professions = profs, lastScan = playerData.lastScan or 0 }
    end

    -- Try to include guild recruitment link so non-guildies can apply
    local guildLink = nil
    local clubId = C_Club and C_Club.GetGuildClubId and C_Club.GetGuildClubId()
    if clubId and C_ClubFinder and C_ClubFinder.GetRecruitmentChatLink then
        C_ClubFinder.RequestPostingInformationFromClubId(clubId)
        guildLink = C_ClubFinder.GetRecruitmentChatLink()
    end

    GF.Sender:SendTo(GF.Protocol.MSG.CB_RECIPE_DATA, {
        guildName = myGuild,
        crafterRecipes = catalog,
        guildLink = guildLink,
    }, sender)
end

--- Handle recipe data response (non-guildie stores it)
---@param data table { guildName, crafterRecipes }
---@param sender string
function CB:OnRecipeDataReceived(data, sender)
    if not data.guildName or not data.crafterRecipes then return end

    local extData = GF.Settings:GetExternalGuildData(data.guildName)
    extData.crafterRecipes = data.crafterRecipes
    extData.lastSync = time()
    if data.guildLink then
        extData.guildLink = data.guildLink
    end

    GF.Events:Fire("GF_EXTERNAL_RECIPES_UPDATED", data.guildName)

    if GF.debug then
        local count = 0
        for _ in pairs(data.crafterRecipes) do count = count + 1 end
        GF.ChatNotify:Debug("Received recipe catalog from " .. sender .. " (" .. count .. " crafters)")
    end
end

------------------------------------------------------------------------
-- Non-guildie: Order submission
------------------------------------------------------------------------

--- Submit a crafting order to a guild via whisper
---@param guildName string
---@param order table Order data from OrderBoard:CreateExternalOrder
function CB:SubmitOrder(guildName, order)
    local peers = self:GetPeers(guildName)
    local sent = false

    -- Send to all online peers so at least one processes it
    for peerName in pairs(peers) do
        GF.Sender:SendTo(GF.Protocol.MSG.CB_ORDER_NEW, {
            guildName = guildName,
            order = order,
        }, peerName)
        sent = true
    end

    if sent then
        GF.ChatNotify:Info("Crafting order submitted to " .. guildName)
    else
        GF.ChatNotify:Warning("No guild members online — order saved locally, will retry.")
    end
end

--- Handle an external crafting order (guild member receives and inserts)
---@param data table { guildName, order }
---@param sender string
function CB:OnExternalOrder(data, sender)
    if not IsInGuild() then return end
    if not data.order then return end

    -- Verify guild name matches
    local myGuild = GetGuildInfo("player")
    if not myGuild or myGuild ~= data.guildName then return end

    local guildData = GF.Settings:GetGuildData()
    if not guildData then return end

    local order = data.order

    -- Verify requester matches sender
    if order.requester ~= sender and order.requester ~= sender:match("^(.+)-") then
        if GF.debug then
            GF.ChatNotify:Debug("External order rejected: requester mismatch from " .. sender)
        end
        return
    end

    -- Check for duplicate order ID
    for _, existing in ipairs(guildData.orders) do
        if existing.id == order.id then
            -- Already have this order (another guild member processed it)
            return
        end
    end

    -- Mark as external and store the requester for status updates
    order.isExternal = true
    order.externalRequester = sender

    -- Insert into guild orders
    guildData.orders[#guildData.orders + 1] = order

    -- Broadcast to guild so all members see it
    GF.Sender:BroadcastNewOrder(order)
    GF.Events:Fire("GF_ORDER_RECEIVED", order)

    -- Acknowledge back to the non-guildie
    GF.Sender:SendTo(GF.Protocol.MSG.CB_ORDER_ACK, {
        orderID = order.id,
        status = "received",
    }, sender)

    if GF.debug then
        GF.ChatNotify:Debug("External order received from " .. sender .. ": " .. (order.recipeName or "?"))
    end
end

--- Handle order acknowledgment (non-guildie receives confirmation)
---@param data table { orderID, status }
---@param sender string
function CB:OnOrderAcknowledged(data, sender)
    if not data.orderID then return end

    GF.ChatNotify:Success("Order #" .. data.orderID:sub(1, 6) .. " received by guild.")

    -- Update local order status
    local guildName = self:GetConnectedGuild()
    if guildName then
        local extData = GF.Settings:GetExternalGuildData(guildName)
        for _, order in ipairs(extData.orders) do
            if order.id == data.orderID then
                order.acknowledged = true
                break
            end
        end
    end
end

--- Handle order status update (non-guildie receives)
---@param data table { orderID, status, crafter }
---@param sender string
function CB:OnExternalOrderUpdate(data, sender)
    if not data.orderID then return end

    -- Search all external guilds for this order
    local names = GF.Settings:GetExternalGuildNames()
    for _, guildName in ipairs(names) do
        local extData = GF.Settings:GetExternalGuildData(guildName)
        for _, order in ipairs(extData.orders) do
            if order.id == data.orderID then
                order.status = data.status
                if data.crafter then
                    order.crafter = data.crafter
                end
                break
            end
        end
    end

    -- Notify the player
    local statusMsg = data.status
    if data.status == GF.ORDER_STATUS.ACCEPTED then
        local crafter = data.crafter and (data.crafter:match("^(.+)-") or data.crafter) or "someone"
        statusMsg = "accepted by " .. crafter
    elseif data.status == GF.ORDER_STATUS.COMPLETED then
        statusMsg = "completed!"
    elseif data.status == GF.ORDER_STATUS.CANCELLED then
        statusMsg = "cancelled"
    end

    GF.ChatNotify:Info("Order #" .. data.orderID:sub(1, 6) .. " — " .. statusMsg)
    GF.Events:Fire("GF_EXTERNAL_ORDER_UPDATED", data.orderID, data.status)
end

--- Notify external requester when their order status changes (guild-side)
---@param order table Order data
function CB:NotifyExternalRequester(order)
    if not order.isExternal or not order.externalRequester then return end
    if not IsInGuild() then return end

    GF.Sender:SendTo(GF.Protocol.MSG.CB_ORDER_UPD, {
        orderID = order.id,
        status = order.status,
        crafter = order.crafter,
    }, order.externalRequester)
end

------------------------------------------------------------------------
-- Slash command support (kept for manual override / status)
------------------------------------------------------------------------

--- Disconnect from a guild
---@param guildName string
---@return boolean success
function CB:Disconnect(guildName)
    if not guildName or guildName == "" then
        return false, "Usage: /vot disconnect <Guild Name>"
    end

    discoveredPeers[guildName] = nil
    GF.Settings:RemoveExternalGuild(guildName)
    GF.ChatNotify:Info("Disconnected from " .. guildName)
    return true
end
