------------------------------------------------------------------------
-- Vault of Truths - Sync/Sender.lua
-- Outbound message queue with throttling
------------------------------------------------------------------------
local ADDON_NAME, GF = ...

GF.Sender = {}
local Sender = GF.Sender
GF:RegisterModule("Sender", Sender)

local sendQueue = {}
local isSending = false
local THROTTLE_INTERVAL = 1.0 -- 1 second between messages (WoW rate limit)
local BURST_LIMIT = 10 -- Initial burst allowance
local burstRemaining = BURST_LIMIT

function Sender:Init()
    -- Reset burst allowance periodically
    C_Timer.NewTicker(10, function()
        burstRemaining = math.min(burstRemaining + 5, BURST_LIMIT)
    end)

    -- On login, announce version and request sync
    GF.Events:On("GF_PLAYER_LOGIN", function()
        C_Timer.After(5, function() -- Delay to let guild roster load
            Sender:AnnounceVersion()
            Sender:RequestSync()
            -- Full state sync (orders, roles, settings) after ledger sync
            C_Timer.After(3, function()
                Sender:RequestFullSync()
            end)
        end)

        -- Periodic sync heartbeat every 5 minutes
        C_Timer.NewTicker(300, function()
            if IsInGuild() then
                Sender:RequestSync()
            end
        end)
    end)
end

--- Send a message to the guild channel
---@param msgType string One of GF.Protocol.MSG
---@param data any Data to serialize and send
function Sender:Send(msgType, data)
    self:_Enqueue(msgType, data, "GUILD", nil)
end

--- Send a message to a specific player via whisper
---@param msgType string One of GF.Protocol.MSG
---@param data any Data to serialize and send
---@param target string Player name to whisper
function Sender:SendTo(msgType, data, target)
    self:_Enqueue(msgType, data, "WHISPER", target)
end

--- Send a message on a custom chat channel
---@param msgType string One of GF.Protocol.MSG
---@param data any Data to serialize and send
---@param channelIndex number Numeric channel index
function Sender:SendChannel(msgType, data, channelIndex)
    self:_Enqueue(msgType, data, "CHANNEL", channelIndex)
end

--- Internal: encode and queue a message
---@param msgType string
---@param data any
---@param channel string "GUILD", "WHISPER", or "CHANNEL"
---@param target string|number|nil Player name for WHISPER, channel index for CHANNEL
function Sender:_Enqueue(msgType, data, channel, target)
    if not IsInGuild() and channel == "GUILD" then return end
    if GF.Settings:Get("syncEnabled") == false then return end

    local encoded = GF.Protocol:Encode(data)
    if not encoded then return end

    local chunks = GF.Protocol:BuildMessage(msgType, encoded)

    -- Add all chunks to the queue
    for _, chunk in ipairs(chunks) do
        sendQueue[#sendQueue + 1] = { message = chunk, channel = channel, target = target }
    end

    if not isSending then
        self:ProcessQueue()
    end
end

--- Process the send queue with throttling
function Sender:ProcessQueue()
    if #sendQueue == 0 then
        isSending = false
        return
    end

    isSending = true
    local entry = table.remove(sendQueue, 1)

    -- Use burst if available, otherwise throttle
    local delay = 0
    if burstRemaining > 0 then
        burstRemaining = burstRemaining - 1
        delay = 0.05 -- Minimal delay during burst
    else
        delay = THROTTLE_INTERVAL
    end

    C_ChatInfo.SendAddonMessage(GF.PREFIX, entry.message, entry.channel, entry.target)

    if GF.debug then
        local dest = entry.channel == "WHISPER" and ("WHISPER:" .. (entry.target or "?")) or entry.channel
        GF.ChatNotify:Debug("Sync sent [" .. dest .. "]: " .. entry.message:sub(1, 50) .. "...")
    end

    C_Timer.After(delay, function()
        Sender:ProcessQueue()
    end)
end

--- Announce our addon version to the guild
function Sender:AnnounceVersion()
    self:Send(GF.Protocol.MSG.VER, {
        version = GF.VERSION,
        protocol = GF.Protocol.PROTOCOL_VERSION,
    })
end

--- Request ledger sync from guild members
function Sender:RequestSync()
    local guildData = GF.Settings:GetGuildData()
    if not guildData then return end

    self:Send(GF.Protocol.MSG.LSYNC_REQ, {
        sinceSyncVersion = guildData.ledger.nextSyncVersion - 1,
    })
end

--- Request full state sync (orders, roles, settings) from guild
function Sender:RequestFullSync()
    self:Send(GF.Protocol.MSG.FULL_SYNC_REQ, {
        requestedAt = time(),
    })
end

--- Broadcast a new ledger entry
---@param entry table Ledger entry
function Sender:BroadcastLedgerEntry(entry)
    local data = { entries = { entry } }
    self:Send(GF.Protocol.MSG.LSYNC_DATA, data)
    self:SavePending(GF.Protocol.MSG.LSYNC_DATA, data)
end

--- Broadcast a new crafting order
---@param order table Order data
function Sender:BroadcastNewOrder(order)
    self:Send(GF.Protocol.MSG.ORDER_NEW, order)
    self:SavePending(GF.Protocol.MSG.ORDER_NEW, order)
end

--- Broadcast an order status update
---@param orderID string
---@param status string
---@param updatedBy string
function Sender:BroadcastOrderUpdate(orderID, status, updatedBy)
    local data = {
        orderID = orderID,
        status = status,
        updatedBy = updatedBy,
        timestamp = GF.Utils:GetTime(),
    }
    self:Send(GF.Protocol.MSG.ORDER_UPD, data)
    self:SavePending(GF.Protocol.MSG.ORDER_UPD, data)
end

--- Broadcast a payout record
---@param player string
---@param amount number
---@param method string
function Sender:BroadcastPayout(player, amount, method)
    local data = {
        player = player,
        amount = amount,
        method = method,
        recordedBy = GF.Utils:GetPlayerFullName(),
        timestamp = GF.Utils:GetTime(),
    }
    self:Send(GF.Protocol.MSG.PAYOUT_REC, data)
    self:SavePending(GF.Protocol.MSG.PAYOUT_REC, data)
end

--- Broadcast guild settings update (owner/officer only)
---@param settings table Guild settings table
function Sender:BroadcastSettings(settings)
    self:Send(GF.Protocol.MSG.SETTINGS, settings)
    self:SavePending(GF.Protocol.MSG.SETTINGS, settings)
end

--- Broadcast a role change
---@param player string
---@param roles table
function Sender:BroadcastRoleUpdate(player, roles)
    local data = {
        player = player,
        roles = roles,
        updatedBy = GF.Utils:GetPlayerFullName(),
    }
    self:Send(GF.Protocol.MSG.ROLE_UPD, data)
    self:SavePending(GF.Protocol.MSG.ROLE_UPD, data)
end

--- Reply to a PING (whispered back to the sender)
---@param syncVersion number
---@param target string Player who sent the PING
function Sender:SendPong(syncVersion, target)
    self:SendTo(GF.Protocol.MSG.PONG, {
        syncVersion = syncVersion,
        playerName = GF.Utils:GetPlayerFullName(),
    }, target)
end

--- Get queue status
---@return number Pending messages in queue
function Sender:GetQueueSize()
    return #sendQueue
end

------------------------------------------------------------------------
-- Pending changes queue (persists across sessions for offline sync)
------------------------------------------------------------------------

--- Save a broadcast to the pending queue so it can be replayed
--- when a peer comes online after we were alone
---@param msgType string
---@param data table
function Sender:SavePending(msgType, data)
    if not IsInGuild() then return end

    local guildData = GF.Settings:GetGuildData()
    if not guildData then return end

    if not guildData._pendingBroadcasts then
        guildData._pendingBroadcasts = {}
    end

    -- Keep max 100 pending items, drop oldest
    if #guildData._pendingBroadcasts >= 100 then
        table.remove(guildData._pendingBroadcasts, 1)
    end

    guildData._pendingBroadcasts[#guildData._pendingBroadcasts + 1] = {
        msgType = msgType,
        data = data,
        savedAt = time(),
    }
end

--- Replay pending broadcasts to a newly online peer
---@param target string Player name to send to
function Sender:ReplayPending(target)
    if not IsInGuild() then return end

    local guildData = GF.Settings:GetGuildData()
    if not guildData or not guildData._pendingBroadcasts then return end

    local count = #guildData._pendingBroadcasts
    if count == 0 then return end

    if GF.debug then
        GF.ChatNotify:Debug("Replaying " .. count .. " pending changes to " .. target)
    end

    for _, pending in ipairs(guildData._pendingBroadcasts) do
        -- Only replay if less than 24 hours old
        if time() - pending.savedAt < 86400 then
            self:SendTo(pending.msgType, pending.data, target)
        end
    end
end

--- Clear pending broadcasts (called after successful sync)
function Sender:ClearPending()
    local guildData = GF.Settings:GetGuildData()
    if guildData then
        guildData._pendingBroadcasts = {}
    end
end

--- Get count of pending broadcasts
---@return number
function Sender:GetPendingCount()
    local guildData = GF.Settings:GetGuildData()
    if not guildData or not guildData._pendingBroadcasts then return 0 end
    return #guildData._pendingBroadcasts
end
