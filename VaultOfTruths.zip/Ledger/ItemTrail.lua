------------------------------------------------------------------------
-- Vault of Truths - Ledger/ItemTrail.lua
-- Tracks the full lifecycle of items through the guild economy:
-- Deposit -> Crafter Withdraw -> Craft -> Deposit Back -> AH Withdraw -> AH List -> Sold
-- Each item gets a trail ID linking all steps together.
------------------------------------------------------------------------
local ADDON_NAME, GF = ...

GF.ItemTrail = {}
local IT = GF.ItemTrail
GF:RegisterModule("ItemTrail", IT)

function IT:Init()
    -- Track AH listings
    if C_AuctionHouse then
        GF.Events:Register("AUCTION_HOUSE_AUCTION_CREATED", function(event, auctionID)
            IT:OnAuctionCreated(auctionID)
        end)
    end
end

--- Ensure the trail log exists
local function EnsureTrailLog()
    local guildData = GF.Settings:GetGuildData()
    if not guildData then return nil end
    if not guildData.itemTrails then
        guildData.itemTrails = {}
    end
    return guildData.itemTrails
end

--- Create a new trail entry for an item event
---@param action string One of GF.ACTIONS
---@param player string Who performed the action
---@param itemID number
---@param itemLink string|nil
---@param quantity number
---@param value number Value in copper (price-locked at event time)
---@param trailID string|nil Existing trail ID to link to, or nil for new trail
---@param note string|nil
---@return string trailID
function IT:LogEvent(action, player, itemID, itemLink, quantity, value, trailID, note)
    local trails = EnsureTrailLog()
    if not trails then return "" end

    trailID = trailID or GF.Utils:GenerateID()

    if not trails[trailID] then
        trails[trailID] = {
            id = trailID,
            itemID = itemID,
            startedBy = player,
            startedAt = GF.Utils:GetTime(),
            events = {},
            status = "active", -- active, crafted, listed, sold, lost
        }
    end

    local trail = trails[trailID]
    trail.events[#trail.events + 1] = {
        action = action,
        player = player,
        itemID = itemID,
        itemLink = itemLink,
        quantity = quantity,
        value = value,
        timestamp = GF.Utils:GetTime(),
        note = note,
    }

    -- Update trail status based on action
    if action == GF.ACTIONS.CRAFT_DEPOSIT then
        trail.status = "crafted"
        trail.craftedItemID = itemID
        trail.craftedBy = player
    elseif action == GF.ACTIONS.AH_LIST then
        trail.status = "listed"
        trail.listedBy = player
    elseif action == GF.ACTIONS.AH_SALE then
        trail.status = "sold"
        trail.soldAt = GF.Utils:GetTime()
        trail.salePrice = value
    end

    -- Trim old trails (keep last 500)
    local count = 0
    for _ in pairs(trails) do count = count + 1 end
    if count > 500 then
        local oldest
        local oldestTime = math.huge
        for id, t in pairs(trails) do
            if t.startedAt < oldestTime then
                oldest = id
                oldestTime = t.startedAt
            end
        end
        if oldest then trails[oldest] = nil end
    end

    return trailID
end

--- Find an active trail for an item (most recent deposit that hasn't been sold)
---@param itemID number
---@return string|nil trailID
function IT:FindActiveTrail(itemID)
    local trails = EnsureTrailLog()
    if not trails then return nil end

    local bestTrail, bestTime = nil, 0
    for id, trail in pairs(trails) do
        if trail.itemID == itemID and trail.status == "active" then
            if trail.startedAt > bestTime then
                bestTrail = id
                bestTime = trail.startedAt
            end
        end
    end
    return bestTrail
end

--- Find a trail for a crafted item (deposited back, ready for AH)
---@param itemID number
---@return string|nil trailID
function IT:FindCraftedTrail(itemID)
    local trails = EnsureTrailLog()
    if not trails then return nil end

    for id, trail in pairs(trails) do
        if trail.craftedItemID == itemID and trail.status == "crafted" then
            return id
        end
    end
    return nil
end

--- Get the full trail for an item
---@param trailID string
---@return table|nil trail { id, itemID, events[], status, ... }
function IT:GetTrail(trailID)
    local trails = EnsureTrailLog()
    if not trails then return nil end
    return trails[trailID]
end

--- Get all trails for a player (as depositor, crafter, or auctioneer)
---@param player string
---@param limit number|nil
---@return table Array of trails
function IT:GetPlayerTrails(player, limit)
    local trails = EnsureTrailLog()
    if not trails then return {} end

    limit = limit or 50
    local results = {}

    for _, trail in pairs(trails) do
        local involved = false
        for _, evt in ipairs(trail.events) do
            if evt.player == player then
                involved = true
                break
            end
        end
        if involved then
            results[#results + 1] = trail
            if #results >= limit then break end
        end
    end

    -- Sort newest first
    table.sort(results, function(a, b) return a.startedAt > b.startedAt end)
    return results
end

--- Get all active/pending trails (items in the pipeline)
---@return table Array of trails
function IT:GetPipelineItems()
    local trails = EnsureTrailLog()
    if not trails then return {} end

    local results = {}
    for _, trail in pairs(trails) do
        if trail.status ~= "sold" and trail.status ~= "lost" then
            results[#results + 1] = trail
        end
    end

    table.sort(results, function(a, b) return a.startedAt > b.startedAt end)
    return results
end

--- Get a human-readable status for a trail
---@param trail table
---@return string status text
---@return string color code
function IT:GetTrailStatusText(trail)
    if trail.status == "active" then
        return "In guild bank", "|cFFFFAA00"
    elseif trail.status == "crafted" then
        local crafter = trail.craftedBy and (trail.craftedBy:match("^(.+)-") or trail.craftedBy) or "?"
        return "Crafted by " .. crafter, "|cFF00AAFF"
    elseif trail.status == "listed" then
        return "Listed on AH", "|cFFFFD700"
    elseif trail.status == "sold" then
        return "Sold for " .. GF.Utils:FormatMoney(trail.salePrice or 0), "|cFF00FF00"
    elseif trail.status == "lost" then
        return "Lost/Unknown", "|cFFFF0000"
    end
    return "Unknown", "|cFF888888"
end

--- Called when an auction is created — link to a trail
function IT:OnAuctionCreated(auctionID)
    -- Try to find what was just listed by checking recent bag changes
    -- This is best-effort; the exact item may not be identifiable
    if GF.debug then
        GF.ChatNotify:Debug("Auction created: " .. tostring(auctionID))
    end
end

--- Hook: call this from Scanner when a deposit is detected
---@param player string
---@param itemID number
---@param itemLink string|nil
---@param quantity number
---@param value number
---@return string trailID
function IT:OnDeposit(player, itemID, itemLink, quantity, value)
    return self:LogEvent(GF.ACTIONS.DEPOSIT, player, itemID, itemLink, quantity, value, nil,
        "Deposited to guild bank")
end

--- Hook: call this from CrafterTracking when mats are withdrawn
---@param player string
---@param itemID number
---@param quantity number
---@param value number
function IT:OnCraftWithdraw(player, itemID, quantity, value)
    local trailID = self:FindActiveTrail(itemID)
    if trailID then
        self:LogEvent(GF.ACTIONS.CRAFT_WITHDRAW, player, itemID, nil, quantity, value, trailID,
            "Withdrawn for crafting")
    end
end

--- Hook: call this from CrafterTracking when a crafted item is deposited back
---@param player string
---@param itemID number
---@param itemLink string|nil
---@param quantity number
---@param value number
function IT:OnCraftDeposit(player, itemID, itemLink, quantity, value)
    -- Try to link to an existing trail where this crafter withdrew mats
    local trails = EnsureTrailLog()
    if not trails then return end

    -- Find the most recent trail where this player withdrew mats
    local bestTrail, bestTime = nil, 0
    for id, trail in pairs(trails) do
        if trail.status == "active" then
            for _, evt in ipairs(trail.events) do
                if evt.action == GF.ACTIONS.CRAFT_WITHDRAW and evt.player == player then
                    if evt.timestamp > bestTime then
                        bestTrail = id
                        bestTime = evt.timestamp
                    end
                end
            end
        end
    end

    if bestTrail then
        self:LogEvent(GF.ACTIONS.CRAFT_DEPOSIT, player, itemID, itemLink, quantity, value, bestTrail,
            "Crafted item deposited")
    else
        -- New trail for the crafted item
        self:LogEvent(GF.ACTIONS.CRAFT_DEPOSIT, player, itemID, itemLink, quantity, value, nil,
            "Crafted item deposited (no mat trail found)")
    end
end

--- Hook: call this from SalesLedger when an item is listed on AH
---@param player string
---@param itemID number
---@param quantity number
---@param listPrice number
function IT:OnAHList(player, itemID, quantity, listPrice)
    local trailID = self:FindCraftedTrail(itemID) or self:FindActiveTrail(itemID)
    if trailID then
        self:LogEvent(GF.ACTIONS.AH_LIST, player, itemID, nil, quantity, listPrice, trailID,
            "Listed on AH for " .. GF.Utils:FormatMoney(listPrice))
    end
end

--- Hook: call this from SalesLedger when an item sells
---@param player string
---@param itemID number
---@param quantity number
---@param salePrice number
function IT:OnAHSale(player, itemID, quantity, salePrice)
    -- Find a listed trail for this item
    local trails = EnsureTrailLog()
    if not trails then return end

    for id, trail in pairs(trails) do
        if trail.status == "listed" and (trail.craftedItemID == itemID or trail.itemID == itemID) then
            self:LogEvent(GF.ACTIONS.AH_SALE, player, itemID, nil, quantity, salePrice, id,
                "Sold on AH")
            return
        end
    end

    -- No trail found — create a standalone sale trail
    local trailID = self:LogEvent(GF.ACTIONS.AH_SALE, player, itemID, nil, quantity, salePrice, nil,
        "AH sale (no deposit trail)")
end
