------------------------------------------------------------------------
-- Vault of Truths - Data/PVPItems.lua
-- Midnight (12.0) PVP tradeable items ONLY. Verified on wowhead.com.
-- All BoP items excluded. Only items that can go in guild bank.
------------------------------------------------------------------------
local ADDON_NAME, GF = ...

GF.PVPItems = {}
local PVPItems = GF.PVPItems

local BIND_ON_PICKUP = 1

PVPItems.CATEGORIES = {
    PVP_HERALDRY = "pvp_heraldry",
    REAGENT = "reagent",
    RECIPE = "recipe",
    ENCHANT_MAT = "enchant_mat",
    BOE_GEAR = "boe_gear",
    MISC = "misc",
}

-- ONLY tradeable Midnight items. Verified each on wowhead.com March 2026.
PVPItems.items = {
    -- ========== GALACTIC HERALDRY (Midnight PVP) ==========
    -- Combatant's is the ONLY tradeable heraldry
    -- Aspirant's (256607) = BoP, Gladiator's (256608) = BoP
    [256559] = { category = "pvp_heraldry", desc = "Galactic Combatant's Heraldry" },

    -- ========== HELIOTROPE JC REAGENT (tradeable) ==========
    -- The gems themselves (241142/3/4) are BoP Unique-Equipped
    -- But the crafting reagent IS tradeable
    [253307] = { category = "reagent", desc = "Infused Heliotrope" },

    -- ========== RECIPES (tradeable, bought with 7500 Honor each) ==========
    [256706] = { category = "recipe", desc = "Design: Determined Heliotrope" },
    [256710] = { category = "recipe", desc = "Design: Enduring Heliotrope" },
    [256712] = { category = "recipe", desc = "Design: Cognitive Heliotrope" },
}

-- Note: Dawncrests (Midnight upgrade system) are CURRENCIES not items.
-- Enchanting mats from DE'ing PVP gear are detected dynamically via CheckLootedItem.
-- BoE gear drops are also detected dynamically.

function PVPItems:IsSoulbound(itemID)
    if not itemID then return true end
    local _, _, _, _, _, _, _, _, _, _, _, _, _, bindType = C_Item.GetItemInfo(itemID)
    return bindType == BIND_ON_PICKUP
end

function PVPItems:IsBankable(itemID)
    if not itemID then return false end
    -- Items in our verified list are ALWAYS bankable (we already confirmed tradeable)
    if self.items[itemID] then return true end
    -- Custom officer-added items are trusted too
    local guildData = GF.Settings:GetGuildData()
    if guildData and guildData.guildSettings.pvpItemIDs and guildData.guildSettings.pvpItemIDs[itemID] then
        return true
    end
    -- For unknown items, check soulbound
    if self:IsSoulbound(itemID) then return false end
    return false
end

--- Smart check: catches known items + BoE gear + valuable reagents
function PVPItems:CheckLootedItem(itemID, itemLink)
    if not itemID then return false, nil end

    -- Known list — skip soulbound check, we verified these
    if self.items[itemID] then
        return true, self.items[itemID].desc
    end

    -- Custom officer-added items — trusted
    local guildData = GF.Settings:GetGuildData()
    if guildData and guildData.guildSettings.pvpItemIDs and guildData.guildSettings.pvpItemIDs[itemID] then
        return true, "Custom tracked item"
    end

    -- For unknown items, reject soulbound
    if self:IsSoulbound(itemID) then return false, nil end

    -- BoE gear rare+
    local _, _, itemQuality, _, _, _, _, _, itemEquipLoc = C_Item.GetItemInfo(itemID)
    if itemEquipLoc and itemEquipLoc ~= "" and itemQuality and itemQuality >= 3 then
        return true, "BoE gear"
    end

    -- Tradeable reagent worth >1g (catches enchanting mats from DE, etc.)
    local _, _, _, _, _, classID = C_Item.GetItemInfo(itemID)
    if classID == 7 or classID == 0 then
        local value = GF.TSM and GF.TSM:GetBestPrice(itemID) or nil
        if value and value > 10000 then
            return true, "Tradeable reagent"
        end
    end

    return false, nil
end

function PVPItems:GetCategory(itemID)
    if not itemID then return nil end
    local entry = self.items[itemID]
    return entry and entry.category or nil
end

function PVPItems:AddCustomItem(itemID, category)
    if self:IsSoulbound(itemID) then
        GF.ChatNotify:Warning("Cannot add soulbound item.")
        return false
    end
    local guildData = GF.Settings:GetGuildData()
    if not guildData then return false end
    if not guildData.guildSettings.pvpItemIDs then guildData.guildSettings.pvpItemIDs = {} end
    guildData.guildSettings.pvpItemIDs[itemID] = {
        category = category or "misc",
        addedBy = GF.Utils:GetPlayerFullName(),
        addedAt = GF.Utils:GetTime(),
    }
    return true
end

function PVPItems:RemoveCustomItem(itemID)
    local guildData = GF.Settings:GetGuildData()
    if not guildData or not guildData.guildSettings.pvpItemIDs then return false end
    guildData.guildSettings.pvpItemIDs[itemID] = nil
    return true
end

function PVPItems:GetAllItemIDs()
    local ids = {}
    for id in pairs(self.items) do ids[#ids + 1] = id end
    local guildData = GF.Settings:GetGuildData()
    if guildData and guildData.guildSettings.pvpItemIDs then
        for id in pairs(guildData.guildSettings.pvpItemIDs) do ids[#ids + 1] = id end
    end
    return ids
end
