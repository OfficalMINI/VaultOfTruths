------------------------------------------------------------------------
-- Vault of Truths - UI/MainFrame.lua
-- Top-level container frame with tab navigation
------------------------------------------------------------------------
local ADDON_NAME, GF = ...

if not GF.UI then GF.UI = {} end
GF.UI.MainFrame = {}
local MF = GF.UI.MainFrame

local mainFrame = nil
local tabGroup = nil

--- Create the main frame (called on first open)
local function CreateMainFrame()
    if mainFrame then return end

    -- Main container
    mainFrame = CreateFrame("Frame", "VaultOfTruthsMainFrame", UIParent, "BackdropTemplate")
    mainFrame:SetSize(900, 620)
    mainFrame:SetPoint("CENTER")
    mainFrame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    mainFrame:SetBackdropColor(0.05, 0.06, 0.09, 0.97)
    mainFrame:SetBackdropBorderColor(0.15, 0.25, 0.4, 0.8)
    mainFrame:SetFrameStrata("HIGH")
    mainFrame:SetMovable(true)
    mainFrame:SetResizable(true)
    mainFrame:EnableMouse(true)
    mainFrame:SetClampedToScreen(true)

    -- Minimum size
    if mainFrame.SetResizeBounds then
        mainFrame:SetResizeBounds(780, 550, 1400, 1000)
    end

    -- Restore saved size
    local savedW = GF.Settings:GetChar("ui.mainFrameWidth")
    local savedH = GF.Settings:GetChar("ui.mainFrameHeight")
    if savedW and savedH and savedW > 0 and savedH > 0 then
        mainFrame:SetSize(savedW, savedH)
    end

    -- Resize handle (bottom-right corner)
    local resizer = CreateFrame("Button", nil, mainFrame)
    resizer:SetSize(16, 16)
    resizer:SetPoint("BOTTOMRIGHT", 0, 0)
    resizer:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resizer:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    resizer:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    resizer:SetScript("OnMouseDown", function()
        mainFrame:StartSizing("BOTTOMRIGHT")
    end)
    resizer:SetScript("OnMouseUp", function()
        mainFrame:StopMovingOrSizing()
        -- Save new size
        GF.Settings:SetChar("ui.mainFrameWidth", math.floor(mainFrame:GetWidth()))
        GF.Settings:SetChar("ui.mainFrameHeight", math.floor(mainFrame:GetHeight()))
    end)

    -- Title bar (drag region)
    local titleBar = CreateFrame("Frame", nil, mainFrame)
    titleBar:SetHeight(32)
    titleBar:SetPoint("TOPLEFT", 0, 0)
    titleBar:SetPoint("TOPRIGHT", 0, 0)
    titleBar:EnableMouse(true)
    titleBar:RegisterForDrag("LeftButton")
    titleBar:SetScript("OnDragStart", function() mainFrame:StartMoving() end)
    titleBar:SetScript("OnDragStop", function()
        mainFrame:StopMovingOrSizing()
        MF:SavePosition()
    end)

    -- Title text
    local titleText = titleBar:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    titleText:SetPoint("LEFT", 12, 0)
    titleText:SetText("|cFF33AAFFVault of Truths|r")

    -- Version + context text
    local versionText = titleBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    versionText:SetPoint("LEFT", titleText, "RIGHT", 8, 0)
    -- Determined at Show() time based on guild status
    mainFrame._versionText = versionText
    versionText:SetText("|cFF888888v" .. GF.VERSION .. "|r")

    -- Close button
    local closeBtn = CreateFrame("Button", nil, titleBar, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function() mainFrame:Hide() end)

    -- Tab content area
    local contentArea = CreateFrame("Frame", nil, mainFrame)
    contentArea:SetPoint("TOPLEFT", 8, -64)
    contentArea:SetPoint("BOTTOMRIGHT", -8, 32)

    -- Status bar
    local statusBar = CreateFrame("Frame", nil, mainFrame)
    statusBar:SetHeight(24)
    statusBar:SetPoint("BOTTOMLEFT", 8, 4)
    statusBar:SetPoint("BOTTOMRIGHT", -8, 4)

    local statusText = statusBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    statusText:SetPoint("LEFT")
    statusText:SetTextColor(0.5, 0.5, 0.5)
    mainFrame._statusText = statusText

    -- "Join Guild" button for non-guildies (hidden by default)
    local joinBtn = CreateFrame("Button", nil, statusBar, "UIPanelButtonTemplate")
    joinBtn:SetSize(90, 20)
    joinBtn:SetPoint("RIGHT", 0, 0)
    joinBtn:SetText("Join Guild")
    joinBtn:Hide()
    joinBtn:SetScript("OnClick", function()
        local guildName = GF.CommunityBridge and GF.CommunityBridge:GetConnectedGuild()
        if not guildName then
            GF.ChatNotify:Warning("No guild discovered yet.")
            return
        end

        local extData = GF.Settings:GetExternalGuildData(guildName)

        -- Try to get guild link from cached data
        if extData.guildLink and extData.guildLink ~= "" then
            -- Print the clickable link directly to chat
            print(GF.ChatNotify and "" or "")
            print("|cFF33AAFF[Vault of Truths]|r Click the guild link below to apply:")
            print(extData.guildLink)
            GF.ChatNotify:Success("Guild link printed to chat — click it to apply!")
            return
        end

        -- No link available — try to find an online guild member to whisper
        local peers = GF.CommunityBridge:GetPeers(guildName)
        local firstPeer = nil
        for peerName in pairs(peers) do
            firstPeer = peerName
            break
        end

        if firstPeer then
            local displayPeer = firstPeer:match("^(.+)-") or firstPeer
            GF.ChatNotify:Info("To join |cFFFFCC00" .. guildName .. "|r, whisper |cFF00FF00" .. displayPeer .. "|r for an invite.")
            GF.ChatNotify:Info("Or search for |cFFFFCC00" .. guildName .. "|r in Guild Finder (press J).")
        else
            GF.ChatNotify:Info("Search for |cFFFFCC00" .. guildName .. "|r in Guild Finder (press J) to apply.")
        end
    end)
    mainFrame._joinGuildBtn = joinBtn

    -- Create content frames for each tab
    local dashboardContent = CreateFrame("Frame", nil, contentArea)
    dashboardContent:SetAllPoints()

    local ledgerContent = CreateFrame("Frame", nil, contentArea)
    ledgerContent:SetAllPoints()

    local craftingContent = CreateFrame("Frame", nil, contentArea)
    craftingContent:SetAllPoints()

    local ahContent = CreateFrame("Frame", nil, contentArea)
    ahContent:SetAllPoints()

    local officerContent = CreateFrame("Frame", nil, contentArea)
    officerContent:SetAllPoints()

    local settingsContent = CreateFrame("Frame", nil, contentArea)
    settingsContent:SetAllPoints()

    -- Store references for sub-panels to use
    mainFrame._contentFrames = {
        dashboard = dashboardContent,
        ledger = ledgerContent,
        crafting = craftingContent,
        ah = ahContent,
        officer = officerContent,
        settings = settingsContent,
    }

    -- Build tabs — non-VoT-guildies only see crafting
    -- Uses IsInVoTGuild() so members of OTHER guilds see the non-guildie layout
    local isVoT = GF.Utils:IsInVoTGuild()
    local tabs
    if isVoT then
        tabs = {
            { id = "dashboard", label = "Dashboard", content = dashboardContent },
            { id = "ledger", label = "Ledger", content = ledgerContent },
            { id = "crafting", label = "Crafting", content = craftingContent },
            { id = "ah", label = "AH", content = ahContent },
            { id = "officer", label = "Officer", content = officerContent },
            { id = "settings", label = "Settings", content = settingsContent },
        }
    else
        tabs = {
            { id = "crafting", label = "Crafting", content = craftingContent },
        }
    end
    mainFrame._isVoTGuild = isVoT

    -- Tab bar area
    local tabBar = CreateFrame("Frame", nil, mainFrame)
    tabBar:SetHeight(32)
    tabBar:SetPoint("TOPLEFT", 0, -32)
    tabBar:SetPoint("TOPRIGHT", 0, -32)

    tabGroup = GF.UI.Widgets:CreateTabGroup(tabBar, tabs, function(tabID)
        MF:OnTabChanged(tabID)
    end)

    -- ESC to close
    tinsert(UISpecialFrames, "VaultOfTruthsMainFrame")

    -- Restore position
    MF:RestorePosition()

    mainFrame:Hide()
end

--- Called when tab changes
function MF:OnTabChanged(tabID)
    if GF.debug then print("|cFF00FF00[VoT]|r Tab changed: " .. tostring(tabID)) end

    -- Update status bar (protected)
    pcall(function() self:UpdateStatus() end)

    -- Role-based tab visibility (protected)
    pcall(function()
        local permLevel = GF.Roles:GetPermissionLevel()
        local officerBtn = tabGroup:GetTabButton("officer")
        if officerBtn then
            if permLevel >= GF.PERMISSIONS.OFFICER then
                officerBtn:Show()
            else
                officerBtn:Hide()
            end
        end
    end)

    -- Initialize/refresh tab content
    local tabRefreshMap = {
        dashboard = GF.UI.Dashboard,
        ledger = GF.UI.LedgerBrowser,
        crafting = GF.UI.CraftingBoard,
        ah = GF.UI.AHPanel,
        officer = GF.UI.OfficerPanel,
        settings = GF.UI.SettingsPanel,
    }
    local panel = tabRefreshMap[tabID]
    if panel and panel.Refresh then
        local ok, err = pcall(panel.Refresh, panel)
        if not ok then
            -- Always show errors regardless of debug mode
            print("|cFFFF0000[Vault of Truths]|r Error in " .. tabID .. ": " .. tostring(err))
        end
    elseif GF.debug then
        print("|cFFFF0000[VoT]|r No panel for tab: " .. tostring(tabID))
    end
end

--- Update the status bar text
function MF:UpdateStatus()
    if not mainFrame or not mainFrame._statusText then return end

    local parts = {}

    local isVoT = GF.Utils:IsInVoTGuild()

    -- Update version text
    if mainFrame._versionText then
        if isVoT then
            mainFrame._versionText:SetText("|cFF888888v" .. GF.VERSION .. " — PVP Guild Economy|r")
        else
            mainFrame._versionText:SetText("|cFF888888v" .. GF.VERSION .. " — Crafting Orders|r")
        end
    end

    if isVoT then
        -- Guild name
        local guild = GetGuildInfo("player")
        if guild then parts[#parts + 1] = guild end

        -- TSM status
        if GF.TSM:IsAvailable() then
            parts[#parts + 1] = "TSM: |cFF00FF00OK|r"
        else
            parts[#parts + 1] = "TSM: |cFFFF0000N/A|r"
        end

        -- Sync peers
        local peers = GF.Receiver:GetPeerCount()
        parts[#parts + 1] = "Peers: " .. peers

        -- Last bank scan
        local guildData = GF.Settings:GetGuildData()
        if guildData and guildData.bankSnapshots.lastScan > 0 then
            parts[#parts + 1] = "Bank: " .. GF.Utils:FormatRelativeTime(guildData.bankSnapshots.lastScan)
        end
    else
        -- Non-guildie status
        local connectedGuild = GF.CommunityBridge:GetConnectedGuild()
        if connectedGuild then
            local peerCount = GF.CommunityBridge:GetPeerCount(connectedGuild)
            parts[#parts + 1] = connectedGuild
            parts[#parts + 1] = "Peers: " .. peerCount

            -- Always show "Join Guild" for non-guildies when connected
            if mainFrame._joinGuildBtn then
                mainFrame._joinGuildBtn:Show()
            end
        else
            parts[#parts + 1] = "Searching for guilds..."
        end
    end

    -- Hide join button for VoT guild members
    if isVoT and mainFrame._joinGuildBtn then
        mainFrame._joinGuildBtn:Hide()
    end

    mainFrame._statusText:SetText(table.concat(parts, " | "))
end

--- Save frame position to per-character settings
function MF:SavePosition()
    if not mainFrame then return end
    local point, _, relPoint, x, y = mainFrame:GetPoint()
    GF.Settings:SetChar("ui.mainFramePoint", { point, nil, relPoint, x, y })
end

--- Restore frame position
function MF:RestorePosition()
    if not mainFrame then return end
    local pos = GF.Settings:GetChar("ui.mainFramePoint")
    if pos and pos[1] then
        mainFrame:ClearAllPoints()
        mainFrame:SetPoint(pos[1], UIParent, pos[3] or "CENTER", pos[4] or 0, pos[5] or 0)
    end
end

--- Show the main frame
function MF:Show()
    CreateMainFrame()
    mainFrame:Show()

    -- Default to last tab or dashboard (non-VoT members always get crafting)
    local lastTab
    if GF.Utils:IsInVoTGuild() then
        lastTab = GF.Settings:GetChar("ui.lastTab") or "dashboard"
    else
        lastTab = "crafting"
    end
    if tabGroup then
        tabGroup:SetActiveTab(lastTab)
    end

    self:UpdateStatus()
end

--- Hide the main frame
function MF:Hide()
    if mainFrame then mainFrame:Hide() end
end

--- Toggle the main frame
function MF:Toggle()
    CreateMainFrame()
    if mainFrame:IsShown() then
        mainFrame:Hide()
    else
        self:Show()
    end
end

--- Get the main frame (for other panels to reference)
---@return Frame|nil
function MF:GetFrame()
    return mainFrame
end

--- Get a specific content frame by tab ID
---@param tabID string
---@return Frame|nil
function MF:GetContentFrame(tabID)
    if mainFrame and mainFrame._contentFrames then
        return mainFrame._contentFrames[tabID]
    end
    return nil
end
