------------------------------------------------------------------------
-- Vault of Truths - UI/LedgerBrowser.lua
-- Sortable, filterable contribution history
------------------------------------------------------------------------
local ADDON_NAME, GF = ...

if not GF.UI then GF.UI = {} end
GF.UI.LedgerBrowser = {}
local LB = GF.UI.LedgerBrowser
local T  = GF.UI.Theme

local initialized = false
local currentFilter = {}
local currentSort = { field = "timestamp", desc = true }

------------------------------------------------------------------------
-- Filter button factory
------------------------------------------------------------------------
local function CreateFilterButton(parent, text, width, onClick)
    local btn = T:ActionButton(parent, text, width, 24)
    btn:SetScript("OnClick", onClick)
    return btn
end

------------------------------------------------------------------------
-- Column header factory (clickable sort label)
------------------------------------------------------------------------
local function CreateColumnHeader(parent, h, xOffset)
    local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    label:SetPoint("LEFT", xOffset, 0)
    if h.width > 0 then label:SetWidth(h.width) end
    label:SetText(h.label)
    label:SetTextColor(unpack(T.COLORS.headerGold))

    local hit = CreateFrame("Button", nil, parent)
    hit:SetPoint("LEFT", xOffset, 0)
    hit:SetSize(h.width > 0 and h.width or 100, 22)
    hit:SetScript("OnClick", function()
        if currentSort.field == h.field then
            currentSort.desc = not currentSort.desc
        else
            currentSort.field = h.field
            currentSort.desc = true
        end
        LB:Refresh()
    end)

    return label
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
local function Init()
    if initialized then return end

    local parent = GF.UI.MainFrame:GetContentFrame("ledger")
    if not parent then return end

    local PAD   = 10     -- outer padding
    local GAP   =  6     -- vertical gap between sections

    ----------------------------------------------------------------
    -- 1.  Filter bar  (card-style)
    ----------------------------------------------------------------
    local filterCard = T:Card(parent)
    filterCard:SetHeight(40)
    filterCard:SetPoint("TOPLEFT",  PAD, -PAD)
    filterCard:SetPoint("TOPRIGHT", -PAD, -PAD)

    local filterLabel = filterCard:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    filterLabel:SetPoint("LEFT", 12, 0)
    filterLabel:SetText("Filter:")
    filterLabel:SetTextColor(unpack(T.COLORS.textDim))

    local allBtn = CreateFilterButton(filterCard, "All", 54, function()
        currentFilter = {}
        LB:Refresh()
    end)
    allBtn:SetPoint("LEFT", filterLabel, "RIGHT", 10, 0)

    local depBtn = CreateFilterButton(filterCard, "Deposits", 76, function()
        currentFilter = { action = GF.ACTIONS.DEPOSIT }
        LB:Refresh()
    end)
    depBtn:SetPoint("LEFT", allBtn, "RIGHT", 6, 0)

    local payBtn = CreateFilterButton(filterCard, "Payouts", 70, function()
        currentFilter = { action = GF.ACTIONS.PAYOUT }
        LB:Refresh()
    end)
    payBtn:SetPoint("LEFT", depBtn, "RIGHT", 6, 0)

    local ahBtn = CreateFilterButton(filterCard, "AH Sales", 76, function()
        currentFilter = { action = GF.ACTIONS.AH_SALE }
        LB:Refresh()
    end)
    ahBtn:SetPoint("LEFT", payBtn, "RIGHT", 6, 0)

    ----------------------------------------------------------------
    -- 2.  Column headers  (card-style header row)
    ----------------------------------------------------------------
    local headerCard = T:Card(parent)
    headerCard:SetHeight(26)
    headerCard:SetPoint("TOPLEFT",  filterCard, "BOTTOMLEFT",  0, -GAP)
    headerCard:SetPoint("TOPRIGHT", filterCard, "BOTTOMRIGHT", 0, -GAP)

    local headers = {
        { field = "timestamp",  label = "Time",   width =  70, point = "LEFT"  },
        { field = "action",     label = "Action", width =  70, point = "LEFT"  },
        { field = "player",     label = "Player", width = 110, point = "LEFT"  },
        { field = "items",      label = "Items",  width = 200, point = "LEFT"  },
        { field = "totalValue", label = "Value",  width =  90, point = "RIGHT" },
        { field = "status",     label = "Status", width =   0, point = "LEFT"  },
    }

    local xOffset = 10
    for _, h in ipairs(headers) do
        CreateColumnHeader(headerCard, h, xOffset)
        xOffset = xOffset + (h.width > 0 and h.width or 100)
    end

    ----------------------------------------------------------------
    -- 3.  Scroll list of ledger entries
    ----------------------------------------------------------------
    local listFrame = CreateFrame("Frame", nil, parent)
    listFrame:SetPoint("TOPLEFT",     headerCard, "BOTTOMLEFT",   0, -GAP)
    listFrame:SetPoint("BOTTOMRIGHT", parent,     "BOTTOMRIGHT", -PAD, 34)

    local list = GF.UI.Widgets:CreateScrollList(listFrame, 22,
        -- row factory
        function(index, contentFrame)
            local row = CreateFrame("Button", nil, contentFrame)
            row:RegisterForClicks("LeftButtonUp")
            row:EnableMouse(true)

            row.time = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            row.time:SetPoint("LEFT", 10, 0)
            row.time:SetWidth(70)
            row.time:SetTextColor(unpack(T.COLORS.textDim))

            row.action = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            row.action:SetPoint("LEFT", 80, 0)
            row.action:SetWidth(70)

            row.player = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.player:SetPoint("LEFT", 150, 0)
            row.player:SetWidth(110)

            row.items = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            row.items:SetPoint("LEFT", 260, 0)
            row.items:SetWidth(200)
            row.items:SetJustifyH("LEFT")
            row.items:SetTextColor(unpack(T.COLORS.textNormal))

            row.value = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            row.value:SetPoint("LEFT", 460, 0)
            row.value:SetWidth(90)
            row.value:SetJustifyH("RIGHT")
            row.value:SetTextColor(unpack(T.COLORS.gold))

            row.status = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            row.status:SetPoint("LEFT", 556, 0)
            row.status:SetPoint("RIGHT", -10, 0)
            row.status:SetTextColor(unpack(T.COLORS.textDim))

            -- Tooltip: show item trail (lifecycle) on hover
            row:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")

                -- Show item tooltip first if available
                if self._itemLinks and #self._itemLinks > 0 then
                    GameTooltip:SetHyperlink(self._itemLinks[1])
                    GameTooltip:AddLine(" ")
                end

                -- Show item trail
                if self._trailData then
                    local trail = self._trailData
                    GameTooltip:AddLine("|cFFFFCC00Item Trail|r", 1, 1, 1)
                    for _, evt in ipairs(trail.events or {}) do
                        local evtPlayer = evt.player and (evt.player:match("^(.+)-") or evt.player) or "?"
                        local evtTime = GF.Utils:FormatRelativeTime(evt.timestamp or 0)
                        local evtValue = evt.value and evt.value > 0 and (" — " .. GF.Utils:FormatMoney(evt.value)) or ""

                        local actionLabels = {
                            [GF.ACTIONS.DEPOSIT] = "|cFF00FF00Deposited|r",
                            [GF.ACTIONS.WITHDRAW] = "|cFFFF4444Withdrawn|r",
                            [GF.ACTIONS.CRAFT_WITHDRAW] = "|cFFFF8800Taken for craft|r",
                            [GF.ACTIONS.CRAFT_DEPOSIT] = "|cFF00AAFFCrafted & deposited|r",
                            [GF.ACTIONS.AH_LIST] = "|cFFFFD700Listed on AH|r",
                            [GF.ACTIONS.AH_SALE] = "|cFF00FF00Sold on AH|r",
                        }
                        local label = actionLabels[evt.action] or evt.action
                        GameTooltip:AddDoubleLine(
                            label .. " by " .. evtPlayer,
                            evtTime .. evtValue,
                            1, 1, 1, 0.6, 0.6, 0.6
                        )
                    end

                    -- Trail status
                    if GF.ItemTrail then
                        local statusText, statusColor = GF.ItemTrail:GetTrailStatusText(trail)
                        GameTooltip:AddLine(" ")
                        GameTooltip:AddLine("Status: " .. statusColor .. statusText .. "|r", 1, 1, 1)
                    end
                elseif not self._itemLinks or #self._itemLinks == 0 then
                    -- No item, no trail — show note as tooltip
                    if self._note and self._note ~= "" then
                        GameTooltip:SetText(self._note, 0.8, 0.8, 0.8, 1, true)
                    end
                end

                GameTooltip:Show()
            end)
            row:SetScript("OnLeave", function()
                GameTooltip:Hide()
            end)

            T:StripeRow(row, index)

            return row
        end,
        -- row updater
        function(row, entry)
            row.time:SetText(GF.Utils:FormatRelativeTime(entry.timestamp))

            local actionColors = {
                [GF.ACTIONS.DEPOSIT]        = "|cFF00FF00",
                [GF.ACTIONS.WITHDRAW]       = "|cFFFF4444",
                [GF.ACTIONS.PAYOUT]         = "|cFFFFAA00",
                [GF.ACTIONS.FEE]            = "|cFF00AAFF",
                [GF.ACTIONS.CRAFT_WITHDRAW] = "|cFFFF8800",
                [GF.ACTIONS.CRAFT_DEPOSIT]  = "|cFF00AAFF",
                [GF.ACTIONS.AH_LIST]        = "|cFFFFD700",
                [GF.ACTIONS.AH_SALE]        = "|cFFFFD700",
                [GF.ACTIONS.AH_RETURN]      = "|cFF00FF88",
            }
            local color = actionColors[entry.action] or "|cFFFFFFFF"
            row.action:SetText(color .. (entry.action or "") .. "|r")

            row.player:SetText(entry.player:match("^(.+)-") or entry.player)
            row.value:SetText(GF.Utils:FormatGold(entry.totalValue))
            row._note = entry.note

            -- Status column
            local statusColors = {
                pending = "|cFFFFAA00",
                credited = "|cFF00FF00",
                crafted = "|cFF00AAFF",
                sold = "|cFFFFD700",
            }
            local statusColor = statusColors[entry.status] or "|cFF888888"
            row.status:SetText(statusColor .. (entry.status or "") .. "|r")

            -- Build items display
            row._itemLinks = {}
            row._trailData = nil
            local firstItemID = nil

            if entry.items and #entry.items > 0 then
                local itemParts = {}
                for _, item in ipairs(entry.items) do
                    local itemName, itemLink = C_Item.GetItemInfo(item.itemID or 0)
                    if not firstItemID and item.itemID then firstItemID = item.itemID end
                    if itemLink then
                        row._itemLinks[#row._itemLinks + 1] = itemLink
                        local qty = item.quantity or item.count or 1
                        if qty > 1 then
                            itemParts[#itemParts + 1] = itemLink .. " x" .. qty
                        else
                            itemParts[#itemParts + 1] = itemLink
                        end
                    elseif itemName then
                        local qty = item.quantity or item.count or 1
                        itemParts[#itemParts + 1] = itemName .. (qty > 1 and (" x" .. qty) or "")
                    elseif item.itemID then
                        local qty = item.quantity or item.count or 1
                        itemParts[#itemParts + 1] = "Item:" .. item.itemID .. (qty > 1 and (" x" .. qty) or "")
                        if not firstItemID then firstItemID = item.itemID end
                        C_Item.GetItemInfo(item.itemID)
                    end
                end
                row.items:SetText(table.concat(itemParts, ", "))
            else
                row.items:SetText("|cFF666666" .. (entry.note or "") .. "|r")
            end

            -- Look up item trail for the tooltip
            if firstItemID and GF.ItemTrail then
                local guildData = GF.Settings:GetGuildData()
                if guildData and guildData.itemTrails then
                    for _, trail in pairs(guildData.itemTrails) do
                        if trail.itemID == firstItemID or trail.craftedItemID == firstItemID then
                            row._trailData = trail
                            break
                        end
                    end
                end
            end
        end
    )
    parent._list = list

    ----------------------------------------------------------------
    -- 4.  Summary footer  (card-style)
    ----------------------------------------------------------------
    local footerCard = T:Card(parent)
    footerCard:SetHeight(28)
    footerCard:SetPoint("BOTTOMLEFT",  PAD, PAD)
    footerCard:SetPoint("BOTTOMRIGHT", -PAD, PAD)

    local footer = footerCard:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    footer:SetPoint("LEFT", 12, 0)
    footer:SetTextColor(unpack(T.COLORS.textDim))
    parent._footer = footer

    initialized = true
end

--- Refresh the ledger browser
function LB:Refresh()
    Init()

    local parent = GF.UI.MainFrame:GetContentFrame("ledger")
    if not parent then return end

    -- Get filtered entries
    local entries = GF.Ledger:GetRecent(500, currentFilter)

    -- Sort
    if currentSort.field then
        table.sort(entries, function(a, b)
            local va, vb = a[currentSort.field], b[currentSort.field]
            if va == nil then return false end
            if vb == nil then return true end
            if currentSort.desc then
                return va > vb
            else
                return va < vb
            end
        end)
    end

    parent._list:SetData(entries)

    -- Update footer
    local totalValue = 0
    for _, e in ipairs(entries) do
        totalValue = totalValue + (e.totalValue or 0)
    end
    parent._footer:SetText(#entries .. " entries | Total value: " .. GF.Utils:FormatGold(totalValue))
end
